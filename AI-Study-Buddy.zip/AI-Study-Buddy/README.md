# AI Study Buddy

A simple AI tool that summarizes long lecture notes and generates quizzes.
